#!/bin/sh
python3 -m unittest discover -s tests  -p '*.py' 2>&1